#include <iostream>
#include <string>
#include "bank.hpp"

using namespace std;

int main(){
    //Create bank with 4 clients and 4 accounts
    Bank testBank(6, 4);
    //Create 4 clients
    //Client* MR;
    testBank.CreateClient(0, "Michal Rucka");
    testBank.CreateClient(1, "Marek Zacek");
    testBank.CreateClient(2, "Rostislav Vrana");
    testBank.CreateClient(3, "Vilem Zamboch");
    //Create 2 partners
    testBank.CreateClient(4, "Pani Vranova");
    testBank.CreateClient(5, "Pani Zambochova");

    //Create 4 different types of bank accounts
    //testBank.CreateAccount(0, "Michal Rucka");
    //testBank.CreateAccount(1, "Michal Rucka");

    return 0;
}
