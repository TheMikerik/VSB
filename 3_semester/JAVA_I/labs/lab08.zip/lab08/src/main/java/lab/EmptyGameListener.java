package lab;

public class EmptyGameListener implements GameListener {

	@Override
	public void stateChanged(int shoots, int hits) {
	}

	@Override
	public void gameOver() {
	}

}
