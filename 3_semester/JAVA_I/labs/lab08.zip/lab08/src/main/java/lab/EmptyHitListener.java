package lab;

public class EmptyHitListener implements HitListener {

	@Override
	public void hit() {
	}

}
