const float triangle[] = {
    0.0f,  0.8f, 0.0f, 1.0f, 0.0f, 0.0f,
    -0.8f, -0.8f, 0.0f, 0.0f, 1.0f, 0.0f,
     0.8f, -0.8f, 0.0f, 0.0f, 0.0f, 1.0f
};