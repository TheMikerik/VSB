#include "Application.h"
#include "ShaderProgram.h"
#include "Model.h"
#include "DrawableObject.h"
#include "Transformation.h"

#include "../models/bushes.h"
#include "../models/tree.h"
#include "../models/triangle.h"
#include "../models/sphere.h"

#include <iostream>
#include <cstdlib>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

void Application::errorCallback(int error, const char* description)
{
    // Forward to the instance's error callback if needed
    std::cerr << "GLFW Error (" << error << "): " << description << std::endl;
}

Application::Application()
    : window(nullptr), currentSceneIndex(0) {}

Application::~Application()
{
    glfwDestroyWindow(window);
    glfwTerminate();
}

void Application::initialization()
{
    glfwSetErrorCallback(errorCallback);
    if (!glfwInit()) {
        std::cerr << "ERROR: could not start GLFW3" << std::endl;
        std::exit(EXIT_FAILURE);
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    window = glfwCreateWindow(800, 600, "OpenGL Application", nullptr, nullptr);
    if (!window) {
        std::cerr << "ERROR: could not create GLFW window" << std::endl;
        glfwTerminate();
        std::exit(EXIT_FAILURE);
    }

    // Make the window's context current
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // Enable vsync

    // Initialize GLEW
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (GLEW_OK != err) {
        std::cerr << "Error initializing GLEW: " << glewGetErrorString(err) << std::endl;
        std::exit(EXIT_FAILURE);
    }

    std::cout << "\n==========INIT INFO==========" << std::endl;
    std::cout << "OpenGL Version: " << glGetString(GL_VERSION) << std::endl;
    std::cout << "Using GLEW " << glewGetString(GLEW_VERSION) << std::endl;
    std::cout << "Vendor: " << glGetString(GL_VENDOR) << std::endl;
    std::cout << "Renderer: " << glGetString(GL_RENDERER) << std::endl;
    std::cout << "GLSL Version: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << std::endl;
    int major, minor, revision;
    glfwGetVersion(&major, &minor, &revision);
    std::cout << "Using GLFW " << major << "." << minor << "." << revision << std::endl;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    glViewport(0, 0, width, height);
    std::cout << "Framebuffer size: " << width << "x" << height << std::endl;
    std::cout << "===============================\n" << std::endl;
}

void Application::createScenes()
{
    std::srand(static_cast<unsigned int>(std::time(0)));

    auto scene1 = std::make_shared<Scene>();
    auto scene2 = std::make_shared<Scene>();
    auto scene3 = std::make_shared<Scene>();

    auto shader1 = std::make_shared<ShaderProgram>("./shaders/vertex_shader.glsl", "./shaders/fragment_shader.glsl");
    auto shader2 = std::make_shared<ShaderProgram>("./shaders/vertex_shader.glsl", "./shaders/fragment_shader_red.glsl");
    auto shader3 = std::make_shared<ShaderProgram>("./shaders/vertex_shader.glsl", "./shaders/fragment_shader_purple.glsl");
    auto shader4 = std::make_shared<ShaderProgram>("./shaders/vertex_shader.glsl", "./shaders/fragment_shader_green.glsl");

    std::vector<std::shared_ptr<ShaderProgram>> shaders = {shader1, shader3, shader4};


    std::vector<float> bushesVertices(std::begin(bushes), std::end(bushes));
    std::vector<float> treeVertices(std::begin(tree), std::end(tree));
    std::vector<float> triangleVertices(std::begin(triangle), std::end(triangle));
    std::vector<float> sphereVertices(std::begin(sphere), std::end(sphere));

    auto bushesModel = std::make_shared<Model>(bushesVertices);
    auto treeModel = std::make_shared<Model>(treeVertices);
    auto triangleModel = std::make_shared<Model>(triangleVertices);
    auto sphereModel = std::make_shared<Model>(sphereVertices);

    for (int i = 0; i < 30; ++i)
    {
        auto randomShader = shaders[std::rand() % shaders.size()];
        auto bushesDrawable = std::make_shared<DrawableObject>(bushesModel, randomShader);

        Transformation bushesTrans;
        bushesTrans.translate(glm::vec3(static_cast<float>(std::rand() % 200 - 100) / 100.0f, 
                                        static_cast<float>(std::rand() % 200 - 100) / 100.0f, 
                                        static_cast<float>(std::rand() % 200 - 100) / 100.0f));
        bushesTrans.rotate(static_cast<float>(std::rand() % 360), glm::vec3(std::rand() % 2, std::rand() % 2, std::rand() % 2));
        bushesTrans.scale(glm::vec3(static_cast<float>(std::rand() % 50) / 100.0f));
        bushesDrawable->setTransformation(bushesTrans);

        scene1->addDrawable(bushesDrawable);
    }

    for (int i = 0; i < 10; ++i)
    {
        auto randomShader = shaders[std::rand() % shaders.size()];
        auto treeDrawable = std::make_shared<DrawableObject>(treeModel, randomShader);

        // Apply random transformations
        Transformation treeTrans;
        treeTrans.translate(glm::vec3(static_cast<float>(std::rand() % 200 - 100) / 100.0f, 
                                        static_cast<float>(std::rand() % 200 - 100) / 100.0f, 
                                        static_cast<float>(std::rand() % 200 - 100) / 100.0f));
        treeTrans.rotate(static_cast<float>(std::rand() % 360), glm::vec3(std::rand() % 2, std::rand() % 2, std::rand() % 2));
        treeTrans.scale(glm::vec3(static_cast<float>(std::rand() % 50) / 100.0f));
        treeDrawable->setTransformation(treeTrans);

        scene1->addDrawable(treeDrawable);
    }

    // Scene 2    
    auto triangleDrawable = std::make_shared<DrawableObject>(triangleModel, shader2);

    scene2->addDrawable(triangleDrawable);

    // Scene 3 - Four spheres positioned symmetrically on coordinate axes
    // Sphere on positive X axis
    auto sphere1 = std::make_shared<DrawableObject>(sphereModel, shader2);
    Transformation sphere1Trans;
    sphere1Trans.translate(glm::vec3(0.5f, 0.0f, 0.0f));
    sphere1Trans.scale(glm::vec3(0.2f));
    sphere1->setTransformation(sphere1Trans);
    scene3->addDrawable(sphere1);

    // Sphere on negative X axis
    auto sphere2 = std::make_shared<DrawableObject>(sphereModel, shader3);
    Transformation sphere2Trans;
    sphere2Trans.translate(glm::vec3(-0.5f, 0.0f, 0.0f));
    sphere2Trans.scale(glm::vec3(0.2f));
    sphere2->setTransformation(sphere2Trans);
    scene3->addDrawable(sphere2);

    // Sphere on positive Y axis
    auto sphere3 = std::make_shared<DrawableObject>(sphereModel, shader4);
    Transformation sphere3Trans;
    sphere3Trans.translate(glm::vec3(0.0f, 0.5f, 0.0f));
    sphere3Trans.scale(glm::vec3(0.2f));
    sphere3->setTransformation(sphere3Trans);
    scene3->addDrawable(sphere3);

    // Sphere on negative Y axis
    auto sphere4 = std::make_shared<DrawableObject>(sphereModel, shader1);
    Transformation sphere4Trans;
    sphere4Trans.translate(glm::vec3(0.0f, -0.5f, 0.0f));
    sphere4Trans.scale(glm::vec3(0.2f));
    sphere4->setTransformation(sphere4Trans);
    scene3->addDrawable(sphere4);

    // Add scenes to application
    scenes.push_back(scene1);
    scenes.push_back(scene2);
    scenes.push_back(scene3);
}

void Application::run()
{
    glEnable(GL_DEPTH_TEST);

    glClearColor(0.59f, 0.76f, 0.92f, 1.0f);
    createScenes();

    if (!scenes.empty()) {
        selectedDrawableIndex = 0;
        std::cout << "Selected Drawable Index: " << selectedDrawableIndex << std::endl;
    }

    // Main rendering loop
    while (!glfwWindowShouldClose(window)) {
        // Clear the screen
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Update rotation for all objects in scene2
        if (currentSceneIndex == 1 && scenes.size() > 1) {
            float time = glfwGetTime();
            float rotationAngle = time * 45.0f; // Rotate 45 degrees per second
            
            auto& drawables = scenes[1]->getDrawables();
            for (auto& drawable : drawables) {
                Transformation triangleTrans;
                triangleTrans.rotate(rotationAngle, glm::vec3(0.0f, 0.0f, 1.0f)); // Rotate around Z-axis
                drawable->setTransformation(triangleTrans);
            }
        }

        if (currentSceneIndex >= 0 && currentSceneIndex < scenes.size()) {
            scenes[currentSceneIndex]->render();
        }

        glfwSwapBuffers(window);
        glfwPollEvents();

        handleInput();
    }

    glDisable(GL_DEPTH_TEST);
}


void Application::handleInput() {
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
    if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS)
        switchScene(0);
    if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS)
        switchScene(1);
    if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS)
        switchScene(2);
}

void Application::switchScene(int index)
{
    if (index >=0 && index < scenes.size()) {
        currentSceneIndex = index;
        selectedDrawableIndex = 0;
    } else {
        std::cerr << "Invalid scene index: " << index << std::endl;
    }
}