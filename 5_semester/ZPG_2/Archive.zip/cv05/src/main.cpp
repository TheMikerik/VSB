#include "Core/Application.h"

int main()
{
    Application app;
    app.initialization();
    app.createScenes();
    app.run();
    return 0;
}