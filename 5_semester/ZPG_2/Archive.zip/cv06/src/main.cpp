#include "Core/Application.h"

int main()
{
    App.initialization();
    App.createScenes();
    App.run();
    return 0;
}