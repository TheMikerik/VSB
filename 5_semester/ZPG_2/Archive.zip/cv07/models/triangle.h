// triangle.h
const float triangle[18] = {
    -1.0f, -1.0f, 0.0f, 1.0f, 0.0f, 0.0f, // Vertex 1: Red
    1.0f, -1.0f, 0.0f, 1.0f, 0.0f, 0.0f, // Vertex 2: Red
    0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, // Vertex 3: Red
};