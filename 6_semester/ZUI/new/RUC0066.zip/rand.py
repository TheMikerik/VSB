import random

def get_move(board):
    return random.choice(['up', 'down', 'left', 'right'])
